export let USERS = [
  {
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'img/thumb/ben.png',
    group: 'Friend'
  },
  {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'img/thumb/max.png',
    group: 'Family'
  },
  {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'img/thumb/adam.jpg',
    group: 'Friend'
  },
  {

    d: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'img/thumb/perry.png',
    group: 'Friend'
  },
  {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'img/thumb/mike.png',
    group: 'Family'
  },
  {
    id: 5,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'img/thumb/ben.png',
    group: 'Friend'
  },
  {
    id: 6,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'img/thumb/max.png',
    group: 'Family'
  }
];