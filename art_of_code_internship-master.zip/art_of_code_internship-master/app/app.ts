import {Component} from '@angular/core';
import {Platform, ionicBootstrap} from 'ionic-angular';
import {ViewChild} from '@angular/core';
import {StatusBar} from 'ionic-native';

// import services
import {PostService} from './services/post-service';
import {UserService} from './services/user-service';

// import page
import {HomePage} from './pages/home/home';
import {PostPage} from './pages/post/post';
import {UserPage} from './pages/user/user';
import {SettingPage} from './pages/setting/setting';
import {LoginPage} from './pages/login/login';
import {RegisterPage} from './pages/register/register';


@Component({
  templateUrl: 'build/app.html',
  queries: {
    nav: new ViewChild('content')
  }
})
export class MyApp {

  private rootPage:any;

  private nav:any;

  private pages = [
    {
      title: 'Home',
      icon: 'ios-home-outline',
      count: 0,
      component: HomePage
    },
    {
      title: 'Settings',
      icon: 'ios-settings-outline',
      count: 0,
      component: SettingPage
    },
    {
      title: 'Logout',
      icon: 'ios-log-out-outline',
      count: 0,
      component: LoginPage
    },
    {
      title: 'Login',
      icon: 'ios-log-in-outline',
      count: 0,
      component: LoginPage
    }
  ];

  constructor(private platform:Platform) {
    this.rootPage = RegisterPage;

    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }

  // on click, go to user timeline
  viewUser(userId) {
    this.nav.push(UserPage, {id: userId})
  }
}

ionicBootstrap(MyApp, [PostService, UserService], {});
