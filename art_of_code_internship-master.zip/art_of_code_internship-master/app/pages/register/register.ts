import {Component} from '@angular/core';
import {NavController} from 'ionic-angular';
import {HomePage} from '../home/home';
import {LoginPage} from '../login/login';

/*
 Generated class for the LoginPage page.

 See http://ionicframework.com/docs/v2/components/#navigation for more info on
 Ionic pages and navigation.
 */
@Component({
  templateUrl: 'build/pages/register/register.html',
})
export class RegisterPage {
  private chat: any;

  constructor(private nav: NavController) {}

  register() {
    this.nav.setRoot(HomePage);
  }

  login() {
    // add your check auth here
    this.nav.setRoot(LoginPage);
  }
}
