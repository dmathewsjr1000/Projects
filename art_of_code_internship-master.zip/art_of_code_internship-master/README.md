# Art of Code Internship


## Overview and Introduction

Welcome to week one of your six week internship. At the end of six weeks you would have built and deployed your first real live iOS application to the Apple App Store. The technologies you will be using are Ionic 2 and Firebase. Ionic is framework that allows developers to quickly build hybrid mobile applications using the latest web technologies. Firebase is a backend-as-a-service (BaaS) platform that allows you save data in realtime without have to build a database from scratch. Both technologies are maintained by Google.

The application you will be building is called Dormies and will allow college students to decorate their dorms together and share ideas for dorm room decorations with a larger community. You can think of it as [Houzz](http://www.houzz.com/) for college students. We will be building a minimal viable product (MVP) that will include a few simple features to get the product "to market" quickly.

These tasks will be broken down into one week sprints where each week will consist completing one feature of the app. We will have morning stand ups via Slack to discuss any roadblocks or issues and will have an evening standup, again via Slack, to do the same. Morning stand ups will occur at 11 AM and evening stand ups will occur at 8 PM. We will have a Google Hangout checking once a week on Sundays at 2 PM.

Also, using [Atom](http://atom.io) as a text editor is a requirement. Please download before writing any code.

### Dormies Application Feature Set

* Week 1 - User authentication (signup/sign in) with email only
* Week 2 - Table view that displays photographs of items
* Week 3 - Detail view that allows the user get more info about each item and be taken to Amazon to purchase (this will be a modal)
* Week 4 - User profile that contains more info about the user (school, hometown, year, location, etc.)
* Week 5 - Invite friends to the platform
* Week 6 - Style the application and submit to the App Store

### Skills you will pick up

* Mobile development
* Firebase
* Angular 2.0
* TypeScript
* ES2015 & ES2016


## Quick Start

1. Clone the repository that contains the application code to your computer
2. cd into the directory and run ```npm install``` to download the project dependencies
3. After installation run ```ionic serve``` and you should see the application load in a browser window on port 8100


## Week 1 - User Authentication and Firebase

During week one you will learn more about user authentication and how to create a signup and login feature for a mobile application. Since we are dealing with web technologies the same steps used to roll these same features for a website.


### Goals

1. Persist application data to Firebase
2. Roll email password Authentication feature
3. Create functioning signup/sign in screen that requires a user to verify their account via email


### Readings

* [Build a Mobile App with Angular 2 and Ionic 2](https://scotch.io/tutorials/build-a-mobile-app-with-angular-2-and-ionic-2)
* [Integrating Firebase with AngularFire2 into AngularJS a& Ionic 2](http://www.clearlyinnovative.com/integrating-firebase-with-angularfire2-into-angularjs-ionic2)
* [Firebase Emails and Password Authentication](https://www.firebase.com/docs/web/guide/login/password.html)
* [Introduction to Git Workflow](https://guides.github.com/introduction/flow/)
* [TypeScript Quickstart](https://www.typescriptlang.org/docs/tutorial.html)


## Resources

* [Ionic 2 Components](http://ionicframework.com/docs/v2/components/)
* [Ionic 2 Documentation](http://ionicframework.com/docs/v2/)
